//
//  UIViewController+FKNetWork.h
//  CrazyLive
//
//  Created by 高飞林 on 2017/10/19.
//

#import <UIKit/UIKit.h>
#import "FKNetWorkUtil.h"

@interface UIViewController (FKNetWork)

@property (nonatomic, strong) FKNetWorkUtil *netWorkUtil;

@end
