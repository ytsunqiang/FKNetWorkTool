//
//  FKNetWorkUtil.m
//  CrazyLive
//
//  Created by 高飞林 on 2017/10/19.
//

#import "FKNetWorkUtil.h"
#import "FKNetWorkTool.h"
#import "CLSafeMutableArray.h"

@interface FKNetWorkUtil ()
@property (nonatomic, strong) CLSafeMutableArray *tools;
@property (nonatomic, strong) CLSafeMutableArray *urls;
@end

@implementation FKNetWorkUtil

- (void)getRequestWithUrl:(NSURL *)url successSelector:(SEL)successSelector failedSelector:(SEL)failedSelector {
    
    FKNetWorkTool *tool = [[FKNetWorkTool alloc] initWithController:self.controller Url:url successSelector:successSelector failedSelector:failedSelector tools:self.tools urls:self.urls];
    
    [self.tools addObject:tool];
}

- (void)getRequestWithUrl:(NSURL *)url success:(successBlock)success failedBlock:(ASIBasicBlock)failed {

    FKNetWorkTool *tool = [[FKNetWorkTool alloc] initWithController:self.controller Url:url success:success failedBlock:failed tools:self.tools urls:self.urls];
    
    [self.tools addObject:tool];
}

- (instancetype)init {
    if (self = [super init]) {
        self.tools = [[CLSafeSetArray alloc] init];
        self.urls = [[CLSafeSetArray alloc] init];
    }
    return  self;
}

- (void)dealloc {
    
    NSLog(@"%@ Dealloc",NSStringFromClass([self class]));

    for (FKNetWorkTool *tool in self.tools.safeArray) {
        [tool clear];
    }
}
@end

@interface FKNetWorkNoDuplicateUtil ()
@property (nonatomic, strong) CLSafeMutableArray *tools;
@property (nonatomic, strong) CLSafeMutableArray *urls;
@end

@implementation FKNetWorkNoDuplicateUtil

- (instancetype)init {
    if (self = [super init]) {
        self.urls = [[CLSafeSetArray alloc] init];
        self.tools = [[CLSafeSetArray alloc] init];
    }
    return  self;
}

- (void)getRequestAndCancleSameRequestWithUrl:(NSURL *)url success:(successBlock)success failedBlock:(ASIBasicBlock)failed {
    
    [self filterRequesWithUrl:url];
    [self.urls addObject:url];
    FKNetWorkTool *tool = [[FKNetWorkTool alloc] initWithController:self.controller Url:url success:success failedBlock:failed tools:self.tools urls:self.urls];
    tool.urls = self.urls;
    [self.tools addObject:tool];
}

- (void)getRequestAndCancleSameRequestWithUrl:(NSURL *)url successSelector:(SEL)successSelector failedSelector:(SEL)failedSelector {
    [self filterRequesWithUrl:url];
    [self.urls addObject:url];
        FKNetWorkTool *tool = [[FKNetWorkTool alloc] initWithController:self.controller Url:url successSelector:successSelector failedSelector:failedSelector tools:self.tools urls:self.urls];
    tool.urls = self.urls;
    [self.tools addObject:tool];
}

- (void)filterRequesWithUrl:(NSURL *)url {
    if ([self.urls containsObject:url]) {
//        NSLog(@"被新的干掉了");
        FKNetWorkTool *tool = [self.tools objectAtIndex:[self.urls indexOfObject:url]];//self.tools[[self.urls indexOfObject:url]];
        [tool clear];
    }
}
- (void)dealloc {
    
    NSLog(@"%@ Dealloc",NSStringFromClass([self class]));
    
    for (FKNetWorkTool *tool in self.tools.safeArray) {
        [tool clear];
    }
}
@end
