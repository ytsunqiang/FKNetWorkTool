//
//  FKNetWorkTool.h
//  test
//
//  Created by 高飞林 on 2017/9/25.
//  Copyright © 2017年 高飞林. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
#import "CLSafeMutableArray.h"
#import "NSObject+FKNetWork.h"

typedef void(^successBlock)(NSDictionary *dict);
@interface FKNetWorkTool : NSObject

@property (nonatomic, weak) UIViewController *controller;

@property (nonatomic, strong) ASIHTTPRequest *request;

@property (nonatomic, weak) CLSafeMutableArray *urls;
- (void)clear;

- (instancetype)initWithController:(UIViewController *)controller Url:(NSURL *)url success:(successBlock)success failedBlock:(ASIBasicBlock)failed  tools:(CLSafeMutableArray *)tools urls:(CLSafeMutableArray *)urls;

- (instancetype)initWithController:(UIViewController *)controller Url:(NSURL *)url successSelector:(SEL)successSelector failedSelector:(SEL)failedSelector  tools:(CLSafeMutableArray *)tools urls:(CLSafeMutableArray *)urls;
//- (void)getRequestWithUrl:(NSURL *)url success:(successBlock)success failedBlock:(ASIBasicBlock)failed;

@end
