//
//  FKNetWorkTool.m
//  test
//
//  Created by 高飞林 on 2017/9/25.
//  Copyright © 2017年 高飞林. All rights reserved.
//

#import "FKNetWorkTool.h"
#import "caiboAppDelegate.h"
#import "CLSafeMutableArray.h"
typedef NS_ENUM(NSInteger, kCallbackType) {
    
    kCallbackTypeBlock = 0,
    kCallbackTypeSelector
};

@interface FKNetWorkTool()

@property (nonatomic, copy) successBlock successBlock;

@property (nonatomic, copy) ASIBasicBlock failedBlock;

@property (nonatomic, weak) CLSafeMutableArray *tools;

@property (nonatomic, assign) SEL successSelector;

@property (nonatomic, assign) SEL failedSelector;

@property (nonatomic, assign) kCallbackType callbackType;

@end

@implementation FKNetWorkTool

- (instancetype)initWithController:(UIViewController *)controller Url:(NSURL *)url successSelector:(SEL)successSelector failedSelector:(SEL)failedSelector tools:(CLSafeMutableArray *)tools urls:(CLSafeMutableArray *)urls{
    if (self = [super init]) {
        self.callbackType = kCallbackTypeSelector;
        self.controller = controller;
        self.tools = tools;
        self.successSelector = successSelector;
        self.failedSelector = failedSelector;
        self.urls = urls;
        [self requestWithUrl:url];
    }
    return self;
}

- (instancetype)initWithController:(UIViewController *)controller Url:(NSURL *)url success:(successBlock)success failedBlock:(ASIBasicBlock)failed  tools:(CLSafeMutableArray *)tools urls:(CLSafeMutableArray *)urls{
    
    if (self = [super init]) {
        self.callbackType = kCallbackTypeBlock;
        self.controller = controller;
        self.tools = tools;
        self.successBlock = success;
        self.failedBlock = failed;
        self.urls = urls;
        [self requestWithUrl:url];
    }
    return self;
}

- (void)requestWithUrl:(NSURL *)url {
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    self.request = request;
    request.timeOutSeconds = 30;
    [request setDefaultResponseEncoding:NSUTF8StringEncoding];
    
    request.delegate = self;
    [request setDidFinishSelector:@selector(requestFinish:)];
    [request setDidFailSelector:@selector(requestFailed:)];
    [request startAsynchronous];
}

- (void)requestFinish:(ASIHTTPRequest *)request {
    
    if (!self.controller) {
        [self clear];
        return;
    }
    
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:request.responseData options:0 error:nil];
    
    if ([dict[@"code"] isEqualToString:@"0000"]) {
        if (self.successBlock && (self.callbackType == kCallbackTypeBlock)) {
//            NSLog(@"成功了");
            self.successBlock(dict);
        }else if (self.successSelector && (self.callbackType == kCallbackTypeSelector)) {
            if ([self.controller respondsToSelector:self.successSelector]) {
                [self.controller performSelector:self.successSelector withObject:dict];
            }
        }
    }else {
            //            show message
            if ([dict[@"message"] length] > 0) {
                [[caiboAppDelegate getAppDelegate] showMessage:[dict valueForKey:@"message"]];
                }
        }
    [self clear];
}

- (void)requestFailed:(ASIHTTPRequest *)request {
    
    if (!self.controller) {
        [self clear];
        return;
    }
    
    if (self.failedBlock && (self.callbackType == kCallbackTypeBlock)) {
        self.failedBlock();
    }else if (self.failedSelector && (self.callbackType == kCallbackTypeSelector)){
        if ([self.controller respondsToSelector:self.failedSelector]) {
            
            [self.controller performSelector:self.failedSelector];
        }
    }
    [self clear];
}

- (void)clear {
    
    [self.request clearDelegatesAndCancel];
    self.request = nil;
    self.successBlock = nil;
    self.failedBlock = nil;
//    NSLog(@"我启动了清除");
    if ([self.tools containsObject:self]) {
        
//        NSLog(@"我被移除了");
        
        if (self.tools.count > [self.tools indexOfObject:self.request.url]) {
//            NSLog(@"我的url被移除了");
            [self.urls removeObjectAtIndex:[self.tools indexOfObject:self.request.url]];
        }
//        NSLog(@"%ld,======%ld",self.tools.count, self.urls.count);
        [self.tools removeObject:self];
    }
    
}
- (void)dealloc {
    [self clear];
    NSLog(@"FKNetWorkToolDealloc");
}

@end
