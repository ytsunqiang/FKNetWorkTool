//
//  NSObject+FKNetWork.h
//  CrazyLive
//
//  Created by 高飞林 on 2017/10/19.
//

#import <Foundation/Foundation.h>
#import "FKNetWorkUtil.h"

@interface NSObject (FKNetWork)

/**
 不会取消以前相同url的请求
 */
@property (nonatomic, strong) FKNetWorkUtil *netWorkUtil;

/**
 取消正在进行的相同url的请求并重新发送请求
 */
@property (nonatomic, strong) FKNetWorkNoDuplicateUtil *netWorkNoDuplicateUtil;
@end
