//
//  NSObject+FKNetWork.m
//  CrazyLive
//
//  Created by 高飞林 on 2017/10/19.
//

#import "NSObject+FKNetWork.h"
#import <objc/runtime.h>

static NSString *key = @"netWorkUtil";
static NSString *netWorkNoDuplicateUtilKey = @"netWorkNoDuplicateUtil";
@implementation NSObject (FKNetWork)
- (void)setNetWorkUtil:(FKNetWorkUtil *)netWorkUtil {
    objc_setAssociatedObject(self, &key, netWorkUtil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (FKNetWorkUtil *)netWorkUtil {
    FKNetWorkUtil *util = objc_getAssociatedObject(self, &key);
    if (util == nil) {
        util = [[FKNetWorkUtil alloc] init];
        self.netWorkUtil = util;
        util.controller = self;
    }
    return util;
}

- (void)setNetWorkNoDuplicateUtil:(FKNetWorkNoDuplicateUtil *)netWorkNoDuplicateUtil {
    objc_setAssociatedObject(self, &netWorkNoDuplicateUtilKey, netWorkNoDuplicateUtil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (FKNetWorkNoDuplicateUtil *)netWorkNoDuplicateUtil {
    FKNetWorkNoDuplicateUtil *util = objc_getAssociatedObject(self, &netWorkNoDuplicateUtilKey);
    if (util == nil) {
        util = [[FKNetWorkNoDuplicateUtil alloc] init];
        self.netWorkNoDuplicateUtil = util;
        util.controller = self;
 }
    return util;
}
@end
