//
//  FKNetWorkUtil.h
//  CrazyLive
//
//  Created by 高飞林 on 2017/10/19.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
@class FKNetWorkTool;
typedef void(^successBlock)(NSDictionary *dict);

@interface FKNetWorkUtil : NSObject

@property (nonatomic, weak) id controller;

- (void)getRequestWithUrl:(NSURL *)url success:(successBlock)success failedBlock:(ASIBasicBlock)failed;

- (void)getRequestWithUrl:(NSURL *)url successSelector:(SEL)successSelector failedSelector:(SEL)failedSelector;

@end

@interface FKNetWorkNoDuplicateUtil : NSObject
@property (nonatomic, weak) id controller;

- (void)getRequestAndCancleSameRequestWithUrl:(NSURL *)url success:(successBlock)success failedBlock:(ASIBasicBlock)failed;

- (void)getRequestAndCancleSameRequestWithUrl:(NSURL *)url successSelector:(SEL)successSelector failedSelector:(SEL)failedSelector;
@end
